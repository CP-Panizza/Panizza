package Panizza

type ExceptionHandle struct {
}

func (e *ExceptionHandle) ExceptionHandleRegist() {

}

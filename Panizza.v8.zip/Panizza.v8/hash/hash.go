package hash

import (
	"reflect"
)

func hash_key_fun(key string) int {
	var char []byte = []byte(key)
	var seed int = 131
	var hash int = 0
	for _, c := range char {
		hash = hash*seed + int(c)
	}
	return (hash & 0x7FFFFFFF)
}

func str_equal(keyA, keyB string) bool {
	return keyA == keyB
}

type list struct {
	key  string
	val  interface{}
	next *list
}

type Hash struct {
	list_node []*list
	hash_fun  func(key string) int
	equal_fun func(keyA, keyB string) bool
	num       int
}

func (hash *Hash) Add(key string, value interface{}) {
	node := new(list)
	node.key = key
	node.val = value
	hval := hash.hash_fun(key) % hash.num
	node.next = hash.list_node[hval]
	hash.list_node[hval] = node
}

func (hash *Hash) Get(key string, out interface{}) bool {
	hval := hash.hash_fun(key) % hash.num
	node := hash.list_node[hval]

	for node != nil && !hash.equal_fun(node.key, key) {
		node = node.next
	}

	if node != nil {
		reflect.ValueOf(out).Elem().Set(reflect.ValueOf(node.val))
		return true
	} else {
		return false
	}
}

func HashCreate(num int, hash_fun func(key string) int, equal_fun func(keyA, keyB string) bool) *Hash {
	h := new(Hash)
	h.num = num
	h.equal_fun = equal_fun
	h.hash_fun = hash_fun
	h.list_node = make([]*list, num)
	for i := 0; i < num; i++ {
		h.list_node[i] = nil
	}
	return h
}

func NewHash(num int) *Hash {
	h := new(Hash)
	h.num = num
	h.equal_fun = str_equal
	h.hash_fun = hash_key_fun
	h.list_node = make([]*list, num)
	for i := 0; i < num; i++ {
		h.list_node[i] = nil
	}
	return h
}
